mkfs.ext2 /dev/sda1
mkfs.ext4 /dev/sda2
